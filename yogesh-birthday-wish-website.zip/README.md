# Yogesh Birthday Website

Flow:
1. Visitor opens Yogesh's birthday page.
2. Visitor enters their name and writes a wish.
3. The wish is sent to Yogesh's configured email through EmailJS.
4. The visitor immediately sees a personalized message:
   "Yogesh says: I love you much much more, [visitor name] ❤️"

Security:
- Keep EMAILJS_PRIVATE_KEY only in `.env` on the server.
- Never put the private key in frontend JavaScript.
- Add your EmailJS Service ID, Template ID and receiving email to `.env`.
- If a private key has been exposed publicly, rotate it in EmailJS.

Run:
npm install
copy .env.example .env
npm start
Open http://localhost:3000
